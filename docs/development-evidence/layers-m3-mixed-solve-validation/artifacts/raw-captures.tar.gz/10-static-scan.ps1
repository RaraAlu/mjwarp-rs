param([string]$RepoRoot,[string]$Output)
$ErrorActionPreference='Stop'
function Keep-Newlines([Text.RegularExpressions.Match]$match) {
    return [regex]::Replace($match.Value, '[^\r\n]', ' ')
}
function Sanitize-Rust([string]$text) {
    $pattern = '(?s:br(?<bh>#{0,16})".*?"\k<bh>|r(?<rh>#{0,16})".*?"\k<rh>|b?"(?:\\.|[^"\\])*"|b?''(?:\\.|[^''\\])*''|/\*.*?\*/)|(?m://.*$)'
    return [regex]::Replace($text, $pattern, [Text.RegularExpressions.MatchEvaluator]{ param($m) Keep-Newlines $m })
}
function Line-Number([string]$text,[int]$index) {
    if($index -le 0){return 1}
    return 1 + ([regex]::Matches($text.Substring(0,$index), "`n")).Count
}
function Test-Ranges([string]$clean) {
    $ranges=@()
    $rx=[regex]'#\s*\[\s*cfg\s*\([^]]*test[^]]*\)\s*\]\s*mod\s+\w+\s*\{'
    foreach($m in $rx.Matches($clean)) {
        $open=$clean.IndexOf('{',$m.Index)
        $depth=0; $end=$clean.Length-1
        for($i=$open;$i -lt $clean.Length;$i++) {
            if($clean[$i] -eq '{'){$depth++}
            elseif($clean[$i] -eq '}'){$depth--; if($depth -eq 0){$end=$i;break}}
        }
        $ranges += ,@($m.Index,$end)
    }
    return ,$ranges
}
function In-Ranges([int]$index,$ranges) {
    foreach($r in $ranges){if($index -ge $r[0] -and $index -le $r[1]){return $true}}
    return $false
}
$typed=@{
 'src/physics/kinetic_energy.rs:446'='kinetic_energy_validate';
 'src/physics/kinetic_energy.rs:532'='kinetic_energy_reduce32';
 'src/physics/mass_matrix/multiply/borrowed/device_energy.rs:276'='device_energy_source_validate';
 'src/physics/mass_solve/sparse/dense.rs:414'='sparse_dense_validate';
 'src/physics/mass_solve/sparse/dense.rs:600'='sparse_dense_gather';
 'src/physics/mass_solve/sparse/dense/small.rs:572'='small_prefix_validate';
 'src/physics/mass_solve/sparse/dense/small.rs:681'='small_prefix_factor';
 'src/physics/mass_solve/sparse/mixed/solve/resident.rs:631'='resident_mixed_gather';
 'src/physics/mass_solve/sparse/mixed/solve/resident.rs:717'='resident_mixed_validate';
 'src/physics/mass_solve/sparse/mixed/solve.rs:465'='mixed_solve_validate'
}
$orchestration=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
@(
 'src/physics/kinetic_energy.rs:696','src/physics/kinetic_energy.rs:707',
 'src/physics/mass_matrix/multiply/borrowed/device_energy.rs:437','src/physics/mass_matrix/multiply/borrowed/device_energy.rs:457','src/physics/mass_matrix/multiply/borrowed/device_energy.rs:465',
 'src/physics/mass_solve/sparse/dense.rs:750','src/physics/mass_solve/sparse/dense.rs:771',
 'src/physics/mass_solve/sparse/dense/small.rs:840','src/physics/mass_solve/sparse/dense/small.rs:862',
 'src/physics/mass_solve/sparse/mixed/solve/resident.rs:871','src/physics/mass_solve/sparse/mixed/solve/resident.rs:891',
 'src/physics/mass_solve/sparse/mixed/solve.rs:694'
)|ForEach-Object{[void]$orchestration.Add($_)}
$typedNames=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
$typed.Values|ForEach-Object{[void]$typedNames.Add($_)}
$abi=@(); $compile=@(); $calls=@(); $excluded=@(); $testCompile=0; $testCalls=0
$files=Get-ChildItem (Join-Path $RepoRoot 'src/physics') -Recurse -File -Filter '*.rs'|Sort-Object FullName
foreach($file in $files){
 $rel=[IO.Path]::GetRelativePath($RepoRoot,$file.FullName).Replace('\','/')
 $text=[IO.File]::ReadAllText($file.FullName)
 $clean=Sanitize-Rust $text
 $ranges=Test-Ranges $clean
 $abiRx=[regex]'unsafe\s+impl\s+KernelAbi\s+for\s+(?<type>\w+)\s*\{(?s:.*?)const\s+NAME\s*:\s*&''static\s+str\s*=\s*"(?<name>[^"]+)"'
 foreach($m in $abiRx.Matches($text)){
  if(In-Ranges $m.Index $ranges){continue}
  $abi += [ordered]@{type=$m.Groups['type'].Value;entry=$m.Groups['name'].Value;file=$rel;line=(Line-Number $text $m.Index)}
 }
 $compileRx=[regex]'(?s)(?:crate::runtime::)?SynchronousKernel::compile\s*\((?<args>.*?)\)'
 foreach($m in $compileRx.Matches($text)){
  if(In-Ranges $m.Index $ranges){$testCompile++;continue}
  $line=Line-Number $text $m.Index
  $strings=@([regex]::Matches($m.Groups['args'].Value,'"(?<s>[A-Za-z_][A-Za-z0-9_]*)"')|ForEach-Object{$_.Groups['s'].Value})
  $entry=if($strings.Count){$strings[-1]}else{$null}
  $compile += [ordered]@{file=$rel;line=$line;entry=$entry;expression=if($entry){$null}else{($m.Groups['args'].Value -replace '\s+',' ').Trim()}}
 }
 $callRx=[regex]'(?s)(?<receiver>[A-Za-z_][A-Za-z0-9_\.\[\]]*)\s*\.\s*(?<method>launch(?:_[a-z0-9_]+)?)\s*\('
 foreach($m in $callRx.Matches($text)){
  if(In-Ranges $m.Index $ranges){$testCalls++;continue}
  $line=Line-Number $text $m.Index
  $key="$rel`:$line"
  $receiver=$m.Groups['receiver'].Value
  $method=$m.Groups['method'].Value
  if($method -eq 'launch' -and $receiver -eq 'self'){
    $excluded += [ordered]@{file=$rel;line=$line;receiver=$receiver;method=$method;reason='local non-kernel method'}
    continue
  }
  if($typed.ContainsKey($key)){$class='typed_wrapper_low_level';$entry=$typed[$key]}
  elseif($orchestration.Contains($key)){$class='wrapper_orchestration';$entry=$null}
  else{$class='unmigrated_raw';$entry=$null}
  $calls += [ordered]@{file=$rel;line=$line;receiver=$receiver;method=$method;classification=$class;entry=$entry}
 }
}
$entryMap=@{}
foreach($site in $compile){if($site.entry){if(-not $entryMap.ContainsKey($site.entry)){$entryMap[$site.entry]=@()};$entryMap[$site.entry]+=$site}}
foreach($item in $abi){if(-not $entryMap.ContainsKey($item.entry)){$entryMap[$item.entry]=@()}}
$entries=@()
foreach($name in @($entryMap.Keys|Sort-Object)){
 $evidence=@($abi|Where-Object entry -eq $name|ForEach-Object{"$($_.type) at $($_.file):$($_.line)"})
 $entries += [ordered]@{entry=$name;migration_status=if($typedNames.Contains($name)){'typed_wrapper'}else{'unmigrated_or_unwrapped'};compile_sites=@($entryMap[$name]|ForEach-Object{"$($_.file):$($_.line)"});kernel_abi_evidence=$evidence}
}
$methods=@('launch','launch_mixed_solve','launch_small_factor','launch_sparse_solve','launch_rne_cacc','launch_tendon_passive','launch_gravity_compensation','launch_fluid_force','launch_flex_hessian','launch_flex_edges','launch_kinetic_energy32')
$defs=@()
$runtimeFiles=@('src/runtime/transfer/kernel.rs','src/runtime/transfer/kernel/kinetic_energy.rs')
foreach($rf in $runtimeFiles){$text=[IO.File]::ReadAllText((Join-Path $RepoRoot $rf));foreach($name in $methods){$m=[regex]::Match($text,"pub\(crate\) unsafe fn $name\s*\(");if($m.Success){$defs += [ordered]@{method=$name;definition="$rf`:$((Line-Number $text $m.Index))"}}}}
foreach($d in $defs){$subset=@($calls|Where-Object method -eq $d.method);$d['typed_low_level_calls']=@($subset|Where-Object classification -eq 'typed_wrapper_low_level').Count;$d['unmigrated_raw_calls']=@($subset|Where-Object classification -eq 'unmigrated_raw').Count;$d['orchestration_calls']=@($subset|Where-Object classification -eq 'wrapper_orchestration').Count}
$record=[ordered]@{
 schema=1
 generated_at=[DateTimeOffset]::UtcNow.ToString('o')
 source_root='src/physics'
 test_exclusion=[ordered]@{method='lexically strip Rust strings/comments, find cfg(test) or cfg(all(test,...)) modules, brace-match each module, and exclude contained sites';excluded_compile_sites=$testCompile;excluded_launch_candidates=$testCalls}
 kernel_abi_types=@($abi)
 kernel_abi_type_count=$abi.Count
 kernel_entry_kinds=@($entries)
 compile_sites=@($compile)
 unresolved_compile_sites=@($compile|Where-Object {$null -eq $_.entry})
 private_launch_methods=@($defs)
 product_call_sites=@($calls|Where-Object classification -ne 'wrapper_orchestration')
 orchestration_call_sites=@($calls|Where-Object classification -eq 'wrapper_orchestration')
 excluded_non_kernel_calls=@($excluded)
 counts=[ordered]@{compile_sites=$compile.Count;unique_entry_kinds=$entries.Count;product_execution_call_sites=@($calls|Where-Object classification -ne 'wrapper_orchestration').Count;typed_wrapper_low_level_calls=@($calls|Where-Object classification -eq 'typed_wrapper_low_level').Count;unmigrated_raw_calls=@($calls|Where-Object classification -eq 'unmigrated_raw').Count;wrapper_orchestration_calls=@($calls|Where-Object classification -eq 'wrapper_orchestration').Count;unresolved_compile_sites=@($compile|Where-Object {$null -eq $_.entry}).Count}
}
$record|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $Output -Encoding utf8NoBOM
