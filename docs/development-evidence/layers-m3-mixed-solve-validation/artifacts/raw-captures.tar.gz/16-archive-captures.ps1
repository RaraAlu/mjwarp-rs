param(
    [Parameter(Mandatory = $true)]
    [string]$RepoRoot
)

$ErrorActionPreference = 'Stop'
$task = '2026-10-18-layers-m3-mixed-solve-validation'
$rawRoot = Join-Path $RepoRoot "target/development-evidence/$task/capture-raw"
$evidenceRoot = Join-Path $RepoRoot 'docs/development-evidence/layers-m3-mixed-solve-validation'
$artifactRoot = Join-Path $evidenceRoot 'artifacts'
$archive = Join-Path $artifactRoot 'raw-captures.tar.gz'
$manifestPath = Join-Path $evidenceRoot 'capture-manifest.json'
$verificationPath = Join-Path $evidenceRoot 'archive-verification.json'

New-Item -ItemType Directory -Path $artifactRoot -Force | Out-Null
$sourceFiles = @(Get-ChildItem -LiteralPath $rawRoot -Recurse -File | Sort-Object FullName)
$members = @(
    foreach ($file in $sourceFiles) {
        [ordered]@{
            path = [IO.Path]::GetRelativePath($rawRoot, $file.FullName).Replace('\', '/')
            bytes = $file.Length
            sha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $file.FullName).Hash.ToLowerInvariant()
        }
    }
)
$manifest = [ordered]@{
    schema = 1
    task_id = $task
    generated_at = [DateTimeOffset]::UtcNow.ToString('o')
    source_root = 'target/development-evidence/2026-10-18-layers-m3-mixed-solve-validation/capture-raw'
    member_count = $members.Count
    members = $members
    raw_files_preserved = $true
    local_ignore_rule_added = $false
}
$manifest | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $manifestPath -Encoding utf8NoBOM

& tar -czf $archive -C $rawRoot .
if ($LASTEXITCODE -ne 0) {
    throw "tar create failed: $LASTEXITCODE"
}

$verifyRoot = Join-Path $RepoRoot "target/development-evidence/$task/archive-verify"
if (Test-Path -LiteralPath $verifyRoot) {
    $verifyRoot = Join-Path $RepoRoot "target/development-evidence/$task/archive-verify-$([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds())"
}
New-Item -ItemType Directory -Path $verifyRoot | Out-Null
& tar -xzf $archive -C $verifyRoot
if ($LASTEXITCODE -ne 0) {
    throw "tar extract failed: $LASTEXITCODE"
}

$mismatches = @()
foreach ($member in $members) {
    $extracted = Join-Path $verifyRoot ($member.path.Replace('/', [IO.Path]::DirectorySeparatorChar))
    if (-not (Test-Path -LiteralPath $extracted -PathType Leaf)) {
        $mismatches += [ordered]@{ path = $member.path; reason = 'missing' }
        continue
    }
    $hash = (Get-FileHash -Algorithm SHA256 -LiteralPath $extracted).Hash.ToLowerInvariant()
    $length = (Get-Item -LiteralPath $extracted).Length
    if ($hash -cne $member.sha256 -or $length -ne $member.bytes) {
        $mismatches += [ordered]@{
            path = $member.path
            reason = 'hash_or_size_mismatch'
            expected_sha256 = $member.sha256
            actual_sha256 = $hash
            expected_bytes = $member.bytes
            actual_bytes = $length
        }
    }
}
$extractedMembers = @(
    Get-ChildItem -LiteralPath $verifyRoot -Recurse -File |
        ForEach-Object { [IO.Path]::GetRelativePath($verifyRoot, $_.FullName).Replace('\', '/') } |
        Sort-Object
)
$sourceNames = @($members.path | Sort-Object)
$extras = @($extractedMembers | Where-Object { $_ -notin $sourceNames })
$missingSource = @($sourceNames | Where-Object { $_ -notin $extractedMembers })
$verification = [ordered]@{
    schema = 1
    task_id = $task
    archive = 'artifacts/raw-captures.tar.gz'
    archive_bytes = (Get-Item -LiteralPath $archive).Length
    archive_sha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $archive).Hash.ToLowerInvariant()
    source_member_count = $members.Count
    extracted_member_count = $extractedMembers.Count
    verified_member_count = $members.Count - $mismatches.Count
    mismatches = $mismatches
    extra_members = $extras
    missing_members = $missingSource
    all_members_equal = ($mismatches.Count -eq 0 -and $extras.Count -eq 0 -and $missingSource.Count -eq 0)
    byte_preserving = ($mismatches.Count -eq 0)
    raw_files_preserved = $true
    extraction_root = [IO.Path]::GetRelativePath($RepoRoot, $verifyRoot).Replace('\', '/')
    local_ignore_rule_added = $false
}
$verification | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $verificationPath -Encoding utf8NoBOM
if (-not $verification.all_members_equal) {
    throw 'archive verification failed'
}

$verification | ConvertTo-Json -Depth 8
