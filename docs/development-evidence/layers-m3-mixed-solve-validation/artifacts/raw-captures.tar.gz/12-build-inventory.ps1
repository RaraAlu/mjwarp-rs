param(
    [Parameter(Mandatory = $true)]
    [string]$RepoRoot,
    [Parameter(Mandatory = $true)]
    [string]$Scan,
    [Parameter(Mandatory = $true)]
    [string]$Output
)

$ErrorActionPreference = 'Stop'
$scanData = Get-Content -Raw -LiteralPath $Scan | ConvertFrom-Json -Depth 100
$manualExcluded = @{
    'src/physics/fluid_force.rs:494' = 'local launch_buffers orchestration helper'
    'src/physics/fluid_force.rs:589' = 'local launch_buffers orchestration helper'
    'src/physics/mass_solve/sparse/mixed/solve/resident.rs:675' = 'local launch_dims sizing helper'
}

$productCalls = @()
$manualHelperCalls = @()
foreach ($call in $scanData.product_call_sites) {
    $key = "$($call.file):$($call.line)"
    if ($manualExcluded.ContainsKey($key)) {
        $manualHelperCalls += [ordered]@{
            file = $call.file
            line = $call.line
            receiver = $call.receiver
            method = $call.method
            reason = $manualExcluded[$key]
            correction = 'manual receiver-definition cross-check'
        }
        continue
    }
    $productCalls += $call
}

$excludedHelpers = @($scanData.excluded_non_kernel_calls) + @($manualHelperCalls)
$literalEntries = @(
    $scanData.compile_sites |
        Where-Object { $_.entry } |
        Select-Object -ExpandProperty entry -Unique |
        Sort-Object
)
$smallFactorEntries = @(
    $scanData.dynamic_compile_resolutions |
        Where-Object { $_.site -eq 'src/physics/mass_solve/sparse/dense/small.rs:610' } |
        Select-Object -ExpandProperty candidates
)

$actualEntries = @()
foreach ($entry in $literalEntries) {
    $record = $scanData.kernel_entry_kinds | Where-Object { $_.entry -eq $entry }
    $actualEntries += [ordered]@{
        entry = $entry
        compile_sites = @($record.compile_sites)
        selection = 'literal'
        migration_status = $record.migration_status
        kernel_abi_evidence = @($record.kernel_abi_evidence)
    }
}
foreach ($entry in $smallFactorEntries) {
    $actualEntries += [ordered]@{
        entry = $entry
        compile_sites = @('src/physics/mass_solve/sparse/dense/small.rs:610')
        selection = 'exhaustive size match, size in 2..=6'
        migration_status = 'typed_wrapper'
        kernel_abi_evidence = @(
            'SmallFactorSpec at src/physics/mass_solve/sparse/dense/small.rs:293',
            'SmallFactorKernel::launch at src/physics/mass_solve/sparse/dense/small.rs:618'
        )
    }
}
$actualEntries = @($actualEntries | Sort-Object entry)

$abiFamilies = @()
foreach ($abi in $scanData.kernel_abi_types) {
    $actual = if ($abi.type -eq 'SmallFactorSpec') {
        @($smallFactorEntries)
    } else {
        @($abi.entry)
    }
    $lowLevel = @(
        $productCalls |
            Where-Object {
                $_.classification -eq 'typed_wrapper_low_level' -and
                $_.entry -eq $abi.entry
            } |
            ForEach-Object { "$($_.file):$($_.line)" }
    )
    $abiFamilies += [ordered]@{
        type = $abi.type
        logical_name = $abi.entry
        definition = "$($abi.file):$($abi.line)"
        actual_cuda_entries = $actual
        typed_low_level_calls = $lowLevel
    }
}

$sourcePath = Join-Path $RepoRoot 'src/physics/mass_solve/sparse/mixed/solve.rs'
$sourceHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $sourcePath).Hash.ToLowerInvariant()
$baseCommit = (git -C $RepoRoot rev-parse HEAD).Trim()
$typedCalls = @($productCalls | Where-Object classification -eq 'typed_wrapper_low_level')
$rawCalls = @($productCalls | Where-Object classification -eq 'unmigrated_raw')
$typedEntries = @($actualEntries | Where-Object migration_status -eq 'typed_wrapper')
$rawEntries = @($actualEntries | Where-Object migration_status -ne 'typed_wrapper')

$inventory = [ordered]@{
    schema = 2
    task_id = '2026-10-18-layers-m3-mixed-solve-validation'
    base_commit = $baseCommit
    source_file = 'src/physics/mass_solve/sparse/mixed/solve.rs'
    source_file_sha256 = $sourceHash
    scope = 'repository-wide current src/physics kernel compile and product launch sites'
    methodology = [ordered]@{
        source = 'current source lexical scan plus receiver-definition cross-check'
        raw_scan = 'capture-raw/11-static-scan-corrected.json'
        preserved_prior_scan = 'capture-raw/10-static-scan.json'
        strings_comments_and_cfg_test_modules_excluded = $true
        low_level_calls_separated_from_wrapper_orchestration = $true
        logical_abi_names_separated_from_actual_cuda_entries = $true
        subtraction_from_historical_counts = $false
        python_executed = $false
        limitations = @(
            'lexical scan does not perform Rust type inference',
            'typed wrapper locations use current-source static evidence',
            'receiver definitions were manually cross-checked for helper false positives'
        )
    }
    counts = [ordered]@{
        compile_call_sites = @($scanData.compile_sites).Count
        actual_cuda_entry_kinds = $actualEntries.Count
        kernel_abi_families = $abiFamilies.Count
        typed_actual_entry_kinds = $typedEntries.Count
        unmigrated_actual_entry_kinds = $rawEntries.Count
        product_low_level_call_sites = $productCalls.Count
        typed_low_level_call_sites = $typedCalls.Count
        unmigrated_low_level_call_sites = $rawCalls.Count
        wrapper_orchestration_call_sites = @($scanData.orchestration_call_sites).Count
        excluded_non_kernel_helpers = $excludedHelpers.Count
        dynamic_compile_sites = @($scanData.dynamic_compile_resolutions).Count
        unresolved_dynamic_compile_sites = @(
            $scanData.dynamic_compile_resolutions |
                Where-Object { $_.certainty -eq 'unresolved' }
        ).Count
    }
    test_exclusion = $scanData.test_exclusion
    kernel_abi_families = $abiFamilies
    actual_cuda_entry_kinds = $actualEntries
    compile_sites = @($scanData.compile_sites)
    dynamic_compile_resolutions = @($scanData.dynamic_compile_resolutions)
    private_launch_methods = @($scanData.private_launch_methods)
    product_low_level_call_sites = $productCalls
    wrapper_orchestration_call_sites = @($scanData.orchestration_call_sites)
    excluded_non_kernel_helpers = $excludedHelpers
    manual_cross_checks = @(
        'launch_buffers is a local orchestration helper at fluid_force.rs:494 and :589',
        'launch_dims is a local sizing helper at mixed/solve/resident.rs:675',
        'SmallFactorSpec logical name expands to five actual CUDA entries',
        'all ten typed low-level call sites bind one of ten KernelAbi families',
        'all eleven private runtime launch methods are represented'
    )
    uncertain = @()
    next_candidate = [ordered]@{
        selected = $false
        reason = 'selection is deferred until this delivery is final'
    }
    acceptance_boundary = [ordered]@{
        inventory_is_current_repository_scan = $true
        repository_wide_historical_counts_reused = $false
        mixed_solve_fused_migrated = $false
        launch_mixed_solve_migrated = $false
        legitimate_recompute_bit_drift_remains = $true
        np01_to_np04_accepted = $false
        t4_hardware_proven = $false
        parent_m3_complete = $false
    }
}

$inventory | ConvertTo-Json -Depth 100 | Set-Content -LiteralPath $Output -Encoding utf8NoBOM
