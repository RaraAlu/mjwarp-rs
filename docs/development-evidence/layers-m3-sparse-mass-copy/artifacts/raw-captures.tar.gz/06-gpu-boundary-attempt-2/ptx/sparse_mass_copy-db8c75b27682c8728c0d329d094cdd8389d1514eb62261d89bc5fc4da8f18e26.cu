
extern "C" __global__ void sparse_mass_copy(const int* meta,const float* matrix,
 const float* unused,float* out,unsigned first,unsigned count,unsigned stride,unsigned work) {
 unsigned w=blockIdx.x*blockDim.x+threadIdx.x;if(w>=work)return;
 unsigned nc=meta[1],n=meta[0];float* L=out+4+(unsigned long long)w*stride;
 for(unsigned j=0;j<nc;++j)L[j]=matrix[4+(unsigned long long)w*nc+j];
 for(unsigned i=0;i<n;++i)L[nc+i]=0.0f;
}
extern "C" __global__ void sparse_mass_update(const int* meta,const float* unused,
 const float* unused2,float* out,unsigned first,unsigned count,unsigned stride,unsigned work) {
 unsigned tid=blockIdx.x*blockDim.x+threadIdx.x;if(tid>=work)return;
 unsigned w=tid/count,u=first+tid%count,n=meta[0];
 const int* rownnz=meta+2;const int* rowadr=rownnz+n;const int* updates=rowadr+n;
 int i=updates[3*u],k=updates[3*u+1],ki=updates[3*u+2];
 float* L=out+4+(unsigned long long)w*stride;
 float tmp=__fdiv_rn(L[ki],L[rowadr[k]+rownnz[k]-1]);
 for(int j=0;j<rownnz[i];++j) {
   float value=__fmul_rn(L[rowadr[k]+j],tmp);
   float ignored;
   asm volatile("atom.global.add.f32 %0, [%1], %2;" : "=f"(ignored) : "l"(L+rowadr[i]+j),"f"(-value) : "memory");
 }
 L[ki]=tmp;
}
extern "C" __global__ void sparse_mass_diag(const int* meta,const float* unused,
 const float* unused2,float* out,unsigned first,unsigned count,unsigned stride,unsigned work) {
 unsigned tid=blockIdx.x*blockDim.x+threadIdx.x;if(tid>=work)return;
 unsigned n=meta[0],nc=meta[1],w=tid/n,i=tid%n;
 const int* rownnz=meta+2;const int* rowadr=rownnz+n;
 float* L=out+4+(unsigned long long)w*stride;
 L[nc+i]=__fdiv_rn(1.0f,L[rowadr[i]+rownnz[i]-1]);
}
