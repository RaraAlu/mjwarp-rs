
extern "C" __global__ void sparse_dense_validate(const int* sources,const float* matrix,
 const float* unused,float* status,unsigned nc,unsigned prefix,unsigned reserved,unsigned worlds) {
 unsigned w=blockIdx.x*blockDim.x+threadIdx.x;if(w>=worlds)return;
 bool valid=true;unsigned long long total=(unsigned long long)nc*worlds;
 for(unsigned j=0;j<4;++j)valid=valid && matrix[j]==-131072.0f && matrix[4+total+j]==-131072.0f;
 const float* input=matrix+4+(unsigned long long)w*nc;
 for(unsigned j=0;j<nc;++j)valid=valid && isfinite(input[j]);
 status[4+w]=valid?1.0f:0.0f;
}
extern "C" __global__ void sparse_dense_gather(const int* sources,const float* matrix,
 const float* unused,float* output,unsigned nc,unsigned prefix,unsigned reserved,unsigned work) {
 unsigned tid=blockIdx.x*blockDim.x+threadIdx.x;if(tid>=work)return;
 unsigned w=tid/prefix,slot=tid%prefix;int source=sources[slot];
 output[4+tid]=source<(int)nc?matrix[4+(unsigned long long)w*nc+source]:0.0f;
}
