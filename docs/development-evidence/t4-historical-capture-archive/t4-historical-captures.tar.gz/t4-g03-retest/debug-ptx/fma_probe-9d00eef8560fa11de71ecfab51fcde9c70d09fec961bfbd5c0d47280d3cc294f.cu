
extern "C" __global__ void fma_probe(const int* m,const float* p,const float* s,
    float* o,unsigned a,unsigned b,unsigned c,unsigned n) {
  if(threadIdx.x==0 && blockIdx.x==0) o[0]=p[0]*s[0]+p[1];
}
