
__device__ float face_dot(const float* a,const float* b) {
  return (a[0]*b[0]+a[1]*b[1])+a[2]*b[2];
}
__device__ void face_cross(float* r,const float* a,const float* b) {
  r[0]=a[1]*b[2]-a[2]*b[1];r[1]=a[2]*b[0]-a[0]*b[2];r[2]=a[0]*b[1]-a[1]*b[0];
}
__device__ void face_polar(float* q,const float F[3][3]) {
  q[0]=q[1]=q[2]=0.0f;q[3]=1.0f;
  for(int iter=0;iter<50;++iter) {
    float x=q[0],y=q[1],z=q[2],s=q[3];
    // Column-major rotation columns, matching Warp's xyzw convention.
    float R[3][3]={{1-2*(y*y+z*z),2*(x*y+s*z),2*(x*z-s*y)},
      {2*(x*y-s*z),1-2*(x*x+z*z),2*(y*z+s*x)},
      {2*(x*z+s*y),2*(y*z-s*x),1-2*(x*x+y*y)}};
    float crosses[3][3];
    for(int c=0;c<3;++c) face_cross(crosses[c],R[c],F[c]);
    float omega[3];float denom=fabsf((face_dot(R[0],F[0])+face_dot(R[1],F[1]))+face_dot(R[2],F[2]))+1.0e-10f;
    for(int k=0;k<3;++k) omega[k]=((crosses[0][k]+crosses[1][k])+crosses[2][k])/denom;
    float w=sqrtf(face_dot(omega,omega));if(w<1.0e-6f) break;
    float rot[4];for(int k=0;k<3;++k) rot[k]=(omega[k]/w)*sinf(0.5f*w);rot[3]=cosf(0.5f*w);
    float next[4];float cross[3];face_cross(cross,rot,q);
    for(int k=0;k<3;++k) next[k]=(rot[3]*q[k]+q[3]*rot[k])+cross[k];
    next[3]=rot[3]*q[3]-face_dot(rot,q);
    float n=sqrtf(((next[0]*next[0]+next[1]*next[1])+next[2]*next[2])+next[3]*next[3]);
    for(int k=0;k<4;++k) q[k]=next[k]/n;
  }
}
extern "C" __global__ void flex_faces(const int* m,const float* params,const float* nodes,
    float* result,unsigned a,unsigned b,unsigned c,unsigned worlds) {
  unsigned w=blockIdx.x*blockDim.x+threadIdx.x;if(w>=worlds) return;
  int nf=m[0];const float* nx=nodes+4+(unsigned long long)w*m[1];
  float* positions=result+4+(unsigned long long)w*31ull*nf;float* quats=positions+27*nf;
  for(int f=0;f<nf;++f) {
    const int* row=m+2+10*f;float t1[3]={0,0,0},t2[3]={0,0,0};
    for(int slot=0;slot<9;++slot) {
      int n=row[1+slot];float* out=positions+27*f+3*slot;
      if(n<0) {out[0]=out[1]=out[2]=0.0f;continue;}
      float g0=0.5f*(-1+2*(slot/2)),g1=0.5f*(-1+2*(slot%2));
      for(int k=0;k<3;++k) {out[k]=nx[3*n+k];t1[k]+=out[k]*g0;t2[k]+=out[k]*g1;}
    }
    float normal[3];face_cross(normal,t1,t2);float F[3][3];
    for(int k=0;k<3;++k) {
      if(row[0]==0) {F[0][k]=normal[k];F[1][k]=t1[k];F[2][k]=t2[k];}
      else if(row[0]==1) {F[0][k]=t2[k];F[1][k]=normal[k];F[2][k]=t1[k];}
      else {F[0][k]=t1[k];F[1][k]=t2[k];F[2][k]=normal[k];}
    }
    face_polar(quats+4*f,F);
  }
}
