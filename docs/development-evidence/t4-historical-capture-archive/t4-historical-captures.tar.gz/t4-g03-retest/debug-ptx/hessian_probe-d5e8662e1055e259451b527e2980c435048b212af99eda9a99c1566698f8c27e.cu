
extern "C" __global__ void hessian_probe(const int* m,const float* p,const float* x,
    const float* e,const int* v,float* o,unsigned n) {
  unsigned i=blockIdx.x*blockDim.x+threadIdx.x;
  if(i<n) o[i]=float(m[0])+p[0]+x[i]+e[i]+float(v[i]);
}
