
extern "C" __global__ void adapter_probe(const int* m,const double* p,const double* s,
    double* o,unsigned a,unsigned b,unsigned c,unsigned n) {
  unsigned i=blockIdx.x*blockDim.x+threadIdx.x;
  if(i<n) o[i]=double(m[0])+p[0]+s[i]+double(a+b+c);
}
